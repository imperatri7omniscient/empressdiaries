/* OMNISCIÁ shared theme: drifting gold dust + gentle reveal on cards */
(function(){
  var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(!document.getElementById('dust')){var c0=document.createElement('canvas');c0.id='dust';c0.setAttribute('aria-hidden','true');document.body.appendChild(c0)}
  var c=document.getElementById('dust');
  if(!reduce){
    var x=c.getContext('2d'),w,h,dpr=Math.min(2,devicePixelRatio||1),pts=[];
    function size(){w=innerWidth;h=innerHeight;c.width=w*dpr;c.height=h*dpr;x.setTransform(dpr,0,0,dpr,0,0)}
    size();addEventListener('resize',size);
    for(var i=0;i<46;i++)pts.push({x:Math.random(),y:Math.random(),r:Math.random()*1.5+.4,s:Math.random()*.00006+.00002,a:Math.random()*6.28,t:Math.random()*.002+.0008});
    (function tick(t){x.clearRect(0,0,w,h);for(var i=0;i<pts.length;i++){var p=pts[i];p.y-=p.s*16;if(p.y<-.02){p.y=1.02;p.x=Math.random()}var tw=.35+.65*Math.abs(Math.sin(t*p.t+p.a));var px=p.x*w+Math.sin(t*.0003+p.a)*14,py=p.y*h;var g=x.createRadialGradient(px,py,0,px,py,p.r*5);g.addColorStop(0,'rgba(255,230,170,'+(.7*tw)+')');g.addColorStop(1,'rgba(255,230,170,0)');x.fillStyle=g;x.beginPath();x.arc(px,py,p.r*5,0,6.283);x.fill()}requestAnimationFrame(tick)})(0);
  }
  if('IntersectionObserver' in window&&!reduce){
    var els=[].slice.call(document.querySelectorAll('.door,.panel,.lede,.note'));
    els.forEach(function(e){e.style.opacity=0;e.style.transform='translateY(22px)';e.style.transition='opacity 1.1s ease,transform 1.1s cubic-bezier(.2,.7,.2,1)'});
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.style.opacity=1;e.target.style.transform='none';io.unobserve(e.target)}})},{threshold:.08});
    els.forEach(function(e){io.observe(e)});
  }
})();
